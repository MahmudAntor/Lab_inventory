<!DOCTYPE html>
<html>
<head>
	<title>INVENTORY</title>
	<style type="text/css">
	body{
		background-color: #B7F5D3; 
	}
		h2{

			text-align: center;
			text-transform: uppercase;
			font-size: 50px;
			color: blue;
			font-family: Comic Sans MS;
		}
		img{
			height: 50%;
			width: 60%;
		}
		
	</style>

</head>
<body>
	<h2>unable to add</h2>
<?php
echo "
<center><img class = 'sorry' src='images/s.jpg' align='middle'/></center>";
?>
</body>
</html>