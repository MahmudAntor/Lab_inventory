<!DOCTYPE html>
<html>
<head>
	<title>test</title>

</head>
<body>
<?php
echo "<img class = 'sorry' src='images/s.jpg'/>";
?>
</body>
</html>