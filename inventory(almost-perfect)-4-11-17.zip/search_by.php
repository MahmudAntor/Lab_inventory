<!DOCTYPE html>

<?php 
    $host = 'localhost' ;
    $user = 'root';
    $pass = '';
    $db = 'inventory';

      $conn = mysqli_connect($host, $user, $pass, $db);
    if(!$conn){
      die('Failed to connect to MySQL: '.mysqli_connect_error());
    }

    $sql = 'SELECT * 
      FROM items';
    //echo ''.$sql.'<br>';
    $query = mysqli_query($conn, $sql);
    /*$sql = 'SELECT * 
    FROM sales';
    
$query = mysqli_query($conn, $sql);*/
    if (!$query){
      die('SQL error : '.mysqli_error($conn));
    }
   ?>
<html>
<head>
  <title>INVENTORY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/table.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

<style>
</style>
	</head>
<body>
<ul class="nav nav-pills">
    <li class="active"><a data-toggle="pill" href="#home">Home</a></li>
    <li><a data-toggle="pill" href="#byquantity">By Quantity</a></li>
    <li><a data-toggle="pill" href="#bytp">By Total Price</a></li>
    <!-- <li><a data-toggle="pill" href="#menu3">Menu 3</a></li> -->
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
     
     <h5>Click any button above to view sorted list to search through</h5>

    </div>

     <div id="byquantity" class="tab-pane fade">
      <h3>Inventory Items List Sorted by their quantity:</h3>
  
  <table class="table table-responsive data-table">
      <thead>
        <tr>
          <th>Item_id</th>
          <th>Name</th>
          <th>Quantity</th>
          <th>Per unit price(buying)</th>
          <th>Total price</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $sql = 'SELECT * FROM items ORDER BY Quantity desc';
          $query = mysqli_query($conn, $sql);
          $no = 1;
          $total = 0;
          while ($row = mysqli_fetch_array($query)) {
            $Total_price = $row['Total_price'] == 0 ? '' : number_format($row['Total_price']);
        echo '<tr>
        <td>'.$row['Item_id'].'</td>
        <td>'.$row['Name'].'</td>
        <td>'.$row['Quantity'].'</td>
    <td>'.$row['Per_unit_buying_price'].'</td>
    <td>'.$row['Total_price'].'</td>
          </tr>';
          $total += $row['Total_price'];
          $no++;
          }
        ?>
      </tbody> 
   <tfoot>
        <tr class="danger">
          <th colspan="4">Total</th>
          <th> <?= number_format($total)?></th>
        </tr>
      </tfoot> 
     
    </table>
  <br><br>
</div>

                                      <!-- ToTal PrIce StaRts -->

      <div id="bytp" class="tab-pane fade">

             <h3>Inventory Items List Sorted by their price:</h3>
    <table class="table table-responsive data-table">
      <thead>
        <tr>
          <th>Item_id</th>
          <th>Name</th>
          <th>Quantity</th>
          <th>Per unit price(buying)</th>
          <th>Total price</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $sql = 'SELECT * FROM items order by Total_price desc';
          $query = mysqli_query($conn, $sql);
          $no = 1;
          $total = 0;
          while ($row = mysqli_fetch_array($query)) {
            $Total_price = $row['Total_price'] == 0 ? '' : number_format($row['Total_price']);
        echo '<tr>
        <td>'.$row['Item_id'].'</td>
        <td>'.$row['Name'].'</td>
        <td>'.$row['Quantity'].'</td>
    <td>'.$row['Per_unit_buying_price'].'</td>
    <td>'.$row['Total_price'].'</td>
          </tr>';
          $total += $row['Total_price'];
          $no++;
          }
      
        ?>
      </tbody> 
     <tfoot>
        <tr class="danger">
          <th colspan="4">Total</th>
          <th> <?= number_format($total)?></th>
        </tr>
      </tfoot>
    </table>
  <br><br>

      </div>
  </div>
</body>
</html> 